//
//  DashBoardView.swift
//  NutriFit
//
//  Created by Nirmal Kumar on 10/26/24.
//

import SwiftUI

struct DashBoardView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    DashBoardView()
}
