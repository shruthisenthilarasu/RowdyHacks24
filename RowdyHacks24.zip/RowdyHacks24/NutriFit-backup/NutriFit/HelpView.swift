import SwiftUI

struct HelpView: View {
    @State private var showWeightGoalAlert = false
    @State private var weightGoal = ""
    @State private var selectedGoal: String = ""
    @State private var navigateToDashboard = false // State for navigation

    var body: some View {
        VStack {
            Text("How can NutriFit help you?")
                .font(.largeTitle)
                .padding()

            Text("Please select your goal:")
                .font(.subheadline)
                .padding()

            HStack {
                Button("Weight Loss") {
                    selectedGoal = "Weight Loss"
                    showWeightGoalAlert = true
                }
                .buttonStyle(PrimaryButtonStyle())

                Button("Weight Gain") {
                    selectedGoal = "Weight Gain"
                    showWeightGoalAlert = true
                }
                .buttonStyle(PrimaryButtonStyle())
            }
            .padding()

            TextField("Weight Goal (lbs)", text: $weightGoal)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
                .disabled(selectedGoal.isEmpty)

            // Navigation link to Dashboard
            NavigationLink(destination: DashBoardView(), isActive: $navigateToDashboard) {
                EmptyView()
            }

            // Go to Dashboard button
            Button(action: {
                navigateToDashboard = true
            }) {
                Text("Go to Dashboard")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .cornerRadius(10.0)
            }
            .padding()
            .disabled(weightGoal.isEmpty) // Disable until weight goal is entered
        }
        .padding()
        .alert(isPresented: $showWeightGoalAlert) {
            Alert(
                title: Text("Set Your Weight Goal"),
                message: Text("Enter your weight goal for \(selectedGoal)"),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .frame(maxWidth: .infinity)
            .background(configuration.isPressed ? Color.blue.opacity(0.7) : Color.blue)
            .cornerRadius(10.0)
    }
}

struct HelpView_Previews: PreviewProvider {
    static var previews: some View {
        HelpView()
    }
}

