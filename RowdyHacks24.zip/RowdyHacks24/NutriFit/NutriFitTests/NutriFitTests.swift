//
//  NutriFitTests.swift
//  NutriFitTests
//
//  Created by Nirmal Kumar on 10/26/24.
//

import Testing

struct NutriFitTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
