//
//  NutriFitApp.swift
//  NutriFit
//
//  Created by Nirmal Kumar on 10/26/24.
//

import SwiftUI

@main
struct NutriFitApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView() // Make sure this matches the name of your login view
        }
    }
}
