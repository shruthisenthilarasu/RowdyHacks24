import SwiftUI

struct HelpView: View {
    @State private var weightGoal = ""
    @State private var selectedGoal: String = ""
    @State private var selectedActivityLevel: String = ""
    @State private var navigateToDashboard = false

    var userName: String // Property to receive the user's name
    var age: Int
    var height: Int
    var weight: Int
    var gender: String

    let activityLevels = [
        "Sedentary",
        "Lightly Active",
        "Moderately Active",
        "Very Active",
        "Super Active"
    ]

    var body: some View {
        VStack {
            Text("How can NutriFit help you?")
                .font(.largeTitle)
                .padding()

            Text("Please select your goal:")
                .font(.subheadline)
                .padding()

            HStack {
                Button("Weight Loss") {
                    selectedGoal = "Weight Loss"
                }
                .buttonStyle(PrimaryButtonStyle(isSelected: selectedGoal == "Weight Loss"))

                Button("Weight Gain") {
                    selectedGoal = "Weight Gain"
                }
                .buttonStyle(PrimaryButtonStyle(isSelected: selectedGoal == "Weight Gain"))
            }
            .padding()

            TextField("Weight Goal (lbs)", text: $weightGoal)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
                .disabled(selectedGoal.isEmpty)

            // Activity Level Picker
            Text("Select Activity Level:")
                .font(.headline)
                .padding()

            Picker("Activity Level", selection: $selectedActivityLevel) {
                ForEach(activityLevels, id: \.self) { level in
                    Text(level).tag(level)
                }
            }
            .pickerStyle(MenuPickerStyle())
            .padding()

            // NavigationLink to DashBoardView with userName and other data passed in
            NavigationLink(destination: DashBoardView(
                userName: userName,
                age: age,
                height: height,
                weight: weight,
                gender: gender,
                activityLevel: selectedActivityLevel,
                weightGoal: selectedGoal,
                weightGoalValue: Double(weightGoal) ?? 0.0 // Convert to Double safely
            ).navigationBarBackButtonHidden(true), isActive: $navigateToDashboard) {
                EmptyView()
            }

            Button(action: {
                if !weightGoal.isEmpty && !selectedGoal.isEmpty && !selectedActivityLevel.isEmpty {
                    navigateToDashboard = true
                }
            }) {
                Text("Continue to Dashboard")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .cornerRadius(10.0)
            }
            .padding()
            .disabled(weightGoal.isEmpty || selectedGoal.isEmpty || selectedActivityLevel.isEmpty) // Ensure all fields are filled
        }
        .padding()
        .navigationBarBackButtonHidden(true) // Hides back button in HelpView
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    var isSelected: Bool // Track whether the button is selected

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.blue.opacity(0.7) : Color.blue) // Change color if selected
            .cornerRadius(10.0)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0) // Optional: Scale effect on press
    }
}

struct HelpView_Previews: PreviewProvider {
    static var previews: some View {
        HelpView(userName: "Preview User", age: 30, height: 70, weight: 180, gender: "Male") // Example user data for preview
    }
}

