import SwiftUI

struct DashBoardView: View {
    var userName: String
    var age: Int
    var height: Int
    var weight: Int
    var gender: String
    var activityLevel: String
    var weightGoal: String
    var weightGoalValue: Double

    // Function to get the current greeting based on the time of day
    private func greeting() -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 0..<12:
            return "Good Morning"
        case 12..<17:
            return "Good Afternoon"
        default:
            return "Good Evening"
        }
    }

    // Example function to calculate water intake
    private func waterIntake() -> (current: Double, recommended: Double) {
        let recommendedWaterIntake = Double(weight) * 0.033 // Approx. 33 mL per kg
        let currentIntake = 0.0 // Placeholder for user input
        return (currentIntake, recommendedWaterIntake)
    }

    // Example function to calculate calorie intake
    private func calorieIntake() -> (logged: Double, total: Double) {
        let totalCalories = calculateCalorieGoal() // Placeholder for total calorie goal
        let loggedCalories = 0.0 // Placeholder for user logged calories
        return (loggedCalories, totalCalories)
    }

    // Placeholder for the calorie goal calculation logic
    private func calculateCalorieGoal() -> Double {
        return weightGoalValue * 10 // Just a placeholder
    }

    var body: some View {
        TabView {
            // Dashboard Content
            VStack(spacing: 20) {
                // Centered Greeting Section with Circle
                Circle()
                    .fill(Color.blue.opacity(0.3))
                    .frame(width: 200, height: 200) // Bigger circle
                    .overlay(
                        Text("\(greeting()),\n\(userName)") // Greeting with user's name
                            .font(.headline)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .padding()
                    )
                    .padding(.top, 40)
                    .padding(.horizontal) // Horizontal padding for centering

                // Water Intake Fraction Button
                let water = waterIntake()
                Button(action: {
                    // Action for water intake button (if needed)
                }) {
                    VStack {
                        Text("Water Intake")
                        Text("\(Int(water.current))/\(Int(water.recommended)) L") // Display current intake out of recommended
                            .font(.largeTitle)
                            .bold()
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(10)
                    .padding()
                }

                // Calorie Intake Fraction Button
                let calories = calorieIntake()
                Button(action: {
                    // Action for calorie intake button (if needed)
                }) {
                    VStack {
                        Text("Calorie Intake")
                        Text("\(Int(calories.logged))/\(Int(calories.total)) cal") // Display logged calories out of total
                            .font(.largeTitle)
                            .bold()
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.bottom, 10) // Reduced bottom padding
                }

                // Recommendation Buttons (Vertical Alignment)
                VStack(spacing: 10) { // Reduced spacing between buttons
                    Button(action: {
                        // Action for meal prep recommendations
                    }) {
                        Text("Meal Prep Recommendations")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(10)
                    }

                    Button(action: {
                        // Action for workout recommendations
                    }) {
                        Text("Workout Recommendations")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.purple)
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 20) // Optional: Add top padding if needed for spacing

            }
            .padding()
            .navigationBarBackButtonHidden(true) // Hide the back button
            .frame(maxWidth: .infinity) // Ensure the VStack stretches to the full width
            .tabItem {
                Image(systemName: "house")
                Text("Dashboard")
            }

            // Placeholder for Food Intake View
            Text("Food Intake View")
                .tabItem {
                    Image(systemName: "fork.knife")
                    Text("Food Intake")
                }

            // Placeholder for Workout Tracker View
            Text("Workout Tracker View")
                .tabItem {
                    Image(systemName: "figure.walk")
                    Text("Workout Tracker")
                }

            // Placeholder for Settings View
            Text("Settings View")
                .tabItem {
                    Image(systemName: "gear")
                    Text("Settings")
                }
        }
    }
}

struct DashBoardView_Previews: PreviewProvider {
    static var previews: some View {
        DashBoardView(userName: "Laav", age: 30, height: 70, weight: 180, gender: "Male", activityLevel: "Moderately Active", weightGoal: "Weight Loss", weightGoalValue: 150.0)
    }
}

