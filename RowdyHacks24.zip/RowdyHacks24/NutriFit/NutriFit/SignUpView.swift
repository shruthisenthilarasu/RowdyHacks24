import SwiftUI

struct SignUpView: View {
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var height = 0
    @State private var weight = 0
    @State private var age = "" // New variable for age
    @State private var gender = "Prefer not to say"
    
    // New state variables for dietary restrictions, preferences, and allergies
    @State private var selectedDietaryRestriction = "None"
    @State private var selectedPreference = "None"
    @State private var selectedAllergy = "None"

    @State private var isAccountCreated = false
    @State private var showError = false
    @State private var errorMessage = ""

    let heights = Array(50...80)
    let weights = Array(50...300)
    let genderOptions = ["Male", "Female", "Prefer not to say"]
    let dietaryRestrictions = ["None", "Vegetarian", "Vegan", "Gluten-Free", "Keto", "Halal", "Kosher"]
    let preferences = ["None", "Low Sugar", "Low Fat", "High Protein"]
    let allergies = ["None", "Peanuts", "Shellfish", "Dairy", "Gluten", "Eggs"]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("Create Account")
                        .font(.largeTitle)
                        .padding(.top)

                    TextField("First Name", text: $firstName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    TextField("Last Name", text: $lastName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    TextField("Email", text: $email)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    SecureField("Password", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    SecureField("Confirm Password", text: $confirmPassword)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    // Age TextField
                    TextField("Age", text: $age)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                        .padding()

                    // Gender Picker
                    Text("Gender")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Gender", selection: $gender) {
                        ForEach(genderOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Height Picker
                    Text("Height (inches)")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Height (inches)", selection: $height) {
                        ForEach(heights, id: \.self) { height in
                            Text("\(height) inches").tag(height)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Weight Picker
                    Text("Weight (pounds)")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Weight (pounds)", selection: $weight) {
                        ForEach(weights, id: \.self) { weight in
                            Text("\(weight) lbs").tag(weight)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Dietary Restrictions Picker
                    Text("Dietary Restrictions")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Dietary Restrictions", selection: $selectedDietaryRestriction) {
                        ForEach(dietaryRestrictions, id: \.self) { restriction in
                            Text(restriction).tag(restriction)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Preferences Picker
                    Text("Dietary Preferences")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Preferences", selection: $selectedPreference) {
                        ForEach(preferences, id: \.self) { preference in
                            Text(preference).tag(preference)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Allergies Picker
                    Text("Allergies")
                        .font(.headline)
                        .padding(.horizontal)
                    Picker("Allergies", selection: $selectedAllergy) {
                        ForEach(allergies, id: \.self) { allergy in
                            Text(allergy).tag(allergy)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Create Account Button
                    Button(action: {
                        createAccount()
                    }) {
                        Text("Create Account")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10.0)
                    }
                    .padding()

                    // NavigationLink to HelpView
                    NavigationLink(destination: HelpView(
                        userName: firstName,
                        age: Int(age) ?? 0, // Convert age to Int
                        height: height,
                        weight: weight,
                        gender: gender
                    ), isActive: $isAccountCreated) {
                        EmptyView()
                    }
                }
                .padding()
                .alert(isPresented: $showError) {
                    Alert(title: Text("Error"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
                }
            }
        }
    }
    
    // Function to create account with validation
    private func createAccount() {
        guard !firstName.isEmpty, !lastName.isEmpty, !email.isEmpty, !password.isEmpty, password == confirmPassword, !age.isEmpty else {
            errorMessage = "Please fill in all fields and ensure passwords match."
            showError = true
            return
        }

        // Simulate account creation (replace with your actual logic)
        print("Account created for \(firstName) \(lastName)")
        isAccountCreated = true // Set to true to navigate to HelpView
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}

